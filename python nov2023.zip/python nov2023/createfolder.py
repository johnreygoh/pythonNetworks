import os
import datetime

dateref = datetime.datetime.now()
mydate = dateref.strftime("%Y%m%d_%H%M")

try:
    foldername = f"folder_{mydate}"
    os.system(f"md {foldername}")
    print("folder created")
except Exception as e:
    print(e)
    




