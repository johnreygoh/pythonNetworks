# collections

# list
# [], editable, mutable
list1 = ["apple","orange","banana"]
print(list1)
print(list1[2])

list1.append("grapes")
print(list1)

list1.remove("apple")
print(list1)

list1.pop()
print(list1)

list1.append(240)
print(list1)

list2 = ["manga","pakwan"]
list1.append(list2)
print(list1)

print(list1[3][1])

list3 = ["red","blue","yellow","purple","pink"]

newlist3 = []

for c in list3:
    newlist3.append(c.upper())

print(newlist3)
list3 = newlist3
print(list3)
newlist3 = []


