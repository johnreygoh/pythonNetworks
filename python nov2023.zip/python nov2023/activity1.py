from activityfunctions import additem,showitems

print("=====================")
print("Register Item")
print("=====================")
print()
print("[a] Add item")
print("[b] Show items")
print()
choice = input("choice: ").lower()

print("\n---------------------")
if choice=="a":
    n = input("Item name: ")
    p = input("Item price: ")
    q = input("Item Quantity: ")
    additem(n,p,q)
elif choice=="b":
    showitems()
