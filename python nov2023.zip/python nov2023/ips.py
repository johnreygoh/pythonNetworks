import ipaddress

network = '192.168.1.0/24'

ips = ipaddress.IPv4Network(network)

for i in ips:
    print(i)
