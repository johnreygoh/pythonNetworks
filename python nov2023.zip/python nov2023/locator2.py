from geopy.geocoders import Nominatim
import ssl
import certifi
import geopy.geocoders

def search_business(business_name):
    # Disable SSL certificate verification for Nominatim requests
    ctx = ssl.create_default_context(cafile=certifi.where())
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE

    geolocator = Nominatim(user_agent="myGeocoder", scheme='http', ssl_context=ctx)

    location = geolocator.geocode(business_name)

    if location:
        print("Location: ", location.address)
        print("Latitude: ", location.latitude)
        print("Longitude: ", location.longitude)
    else:
        print("Location not found.")

if __name__ == '__main__':
    business_name = "The Medical City Philippines"
    print("Searching %s" % business_name)
    search_business(business_name)
