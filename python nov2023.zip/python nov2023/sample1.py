# variables
# fn = "john"
# ln = "doe"
# age = 34

print("---------------------------------")
print("voter age check")
print("---------------------------------")
fn = input("Enter first name:")
ln = input("Enter last name:")
# int(), float(), str()
age = int(input("Enter age:"))

if age >= 100:
    print("Welcome %s %s %.2f. Thank you for voting." %(fn,ln,age))
    # print(f"Welcome {fn} {ln} {age}. Ready to vote.")

elif age >=18 and age <=99:
    print("Welcome %s %s %.2f. Ready to vote." %(fn,ln,age))

else:
    print("Welcome %s %s %.2f. Not ready to vote." %(fn,ln,age))

