import datetime

# open file
try:
    file1 = open("testfile2.txt","a")
    # file1.write(f"{datetime.datetime.now()} \n")
    file1.write("%s \n" %(datetime.datetime.now()))
    print("file write ok")
    file1.close()
except ValueError as ve:
    print(ve)
except NameError as ne:
    print(ne)
except AttributeError as ae:   
    print(ae)

