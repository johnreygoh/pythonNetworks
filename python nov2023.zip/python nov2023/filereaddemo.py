try:
    filetoread = open("testfile2.txt","r")
    # contents = filetoread.readlines()
    # print(contents[0])
    
    contents = filetoread.read()
    print(contents)
    filetoread.close()
except ValueError as ve:
    print(ve)