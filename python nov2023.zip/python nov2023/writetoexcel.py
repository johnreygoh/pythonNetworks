import os

tryagain = True

while(tryagain):

    try:
        os.system("cls")
    except ValueError as ve:
        print(ve)

    print("===============")
    print("Contacts")
    print("===============")
    print()

    print("Add a new contact")
    n = input("Enter name: ")
    d = input("Enter department: ")
    m = input("Enter mobile number: ")

    try:
        contactsfile = open("contacts.csv","a")
        contactsfile.write(f"{n},{d},{m}\n")
        contactsfile.close()
        print("new contact added")
    except ValueError as ve:
        print(ve)
    
    runagain = input("Press X to exit: ")
    if runagain=="X" or runagain=="x":
        tryagain=False
    else:
        tryagain=True