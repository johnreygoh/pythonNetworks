# for python 3.3+
# ../python312/lib/collection/__init__.py
# add:
# from _collections_abc import iterator
from pygeocoder import Geocoder

def search_business(name):
    result = Geocoder(api_key="AIzaSyB0zHaWS9DxjjZABByUuibGjDfqGSb5AL8").geocode(name)
    for i in result:
        print(i)

search_business("Facebook")






