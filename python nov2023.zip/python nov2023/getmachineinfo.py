import socket

def getmachineinfo():
    try:
        pcname = socket.gethostname()
        pcip = socket.gethostbyname(pcname)
        print(f"{pcname} {pcip}") 
    except Exception as e:
        print(e)

# if __name__=='__main__':
#     getmachineinfo()

getmachineinfo()
