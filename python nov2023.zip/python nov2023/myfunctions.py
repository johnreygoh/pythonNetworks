# custom functions

# function no param
def greetme():
    print("How's your day?")

# function that returns value
def getfullname(firstname, lastname):
    fullname = firstname.upper() + " " + lastname.upper()
    return fullname