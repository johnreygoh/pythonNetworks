import datetime

def additem(name,price,quantity):
    try:
        file1 = open("activity1.csv","a")
        d = datetime.datetime.now().strftime("%Y-%m-%d")
        file1.write(f"{name},{price},{quantity},{d}\n")
        file1.close()
    except ValueError as ve:
        print(ve)

def showitems():
    try:
        file1 = open("activity1.csv","r")
        print(file1.read())
        file1.close()
    except ValueError as ve:
        print(ve)
    except FileNotFoundError as fnfe:
        temp = open("activity1.csv","w")
        temp.close()