# web scraping
import requests
from bs4 import BeautifulSoup
import time

def weblinks(page,pageUrl):
    try:
        if(page>0):
            url = pageUrl
            code = requests.get(url)
            plain = code.text
            s = BeautifulSoup(plain, "html.parser")
            for link in s.find_all('a'):
                # print(link.get('href'))
                li = str(link.get('href'))
                if li.startswith('htt'):
                    response = requests.get(li)
                    if response.status_code==200:
                        print(f"{li}: active")
                    else:
                        print(f"{li}: inactive")
                    
                time.sleep(2)
                    

    except Exception as e:
        print(e)

weblinks(1,"https://stlukes.com.ph/")


