# dictionary
# {}, key-value
d1 = {"name":"hannah","age":23,"city":"Makati"}
print(d1)
print(d1["name"])

d1["gender"] = "female"
print(d1)

d1["age"] = ""
print(d1)

d1.pop("age")
print(d1)

for i in d1:
    d1[i] = d1[i].upper()

print(d1)