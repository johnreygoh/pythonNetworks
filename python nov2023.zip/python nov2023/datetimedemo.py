import datetime

dateref = datetime.datetime.now()
print(dateref)

getday = dateref.strftime("%D %d %A %a %m %B %b %Y %H %M %S")
getdate1 = dateref.strftime("%B %d, %Y [%A] %H:%M:%S")
print(getdate1)