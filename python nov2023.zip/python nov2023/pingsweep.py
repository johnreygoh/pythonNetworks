import subprocess
import ipaddress
import socket
import datetime

def is_active(ip):
    try:
        subprocess.check_call(['ping','-n','1',ip], 
                              stdout = subprocess.DEVNULL, 
                              stderr = subprocess.DEVNULL)
        return True
        # print("active")         
    except subprocess.CalledProcessError:
        return False
        # print("inactive")


def scan_network(network):
    active_ips = []

    dateref = datetime.datetime.now()
    activelog = open(f"activelog_{dateref.strftime('%Y%m%d%H%M')}.csv","w")

    for ip in ipaddress.IPv4Network(network):
        try:
            if is_active(str(ip)):
                active_ips.append(str(ip))
                print(f"{ip}: {str(socket.gethostbyaddr(str(ip))[0])} : active") 
                activelog.write(f"{ip},{str(socket.gethostbyaddr(str(ip))[0])},active\n")
            else:
                print(f"{ip}: {str(socket.gethostbyaddr(str(ip))[0])} : inactive")    
        except socket.herror:
                print(f"{ip}: host name not found : inactive")    

    activelog.close()

    return active_ips

print("====================")
print("ping sweep")
print("====================")
print()

# 10.10.103.0/24
# network = input("Enter network address: ")
network = "10.10.103.0/24"
activeips = scan_network(network)
print(activeips)




