import socket
import os

def findpcbyip():
    try:
        # 10.10.103.145
        ip = str(input("Enter IP address of remote machine: "))
        pcname = socket.gethostbyaddr(ip)
        print(f"{ip}:{pcname[0]}")
    except Exception as e:
        print(e)

def findpcbyname():
    try:
        # pythonpc09.themedicalcity.com
        pcname = input("Enter pc name: ")
        ip = socket.gethostbyaddr(pcname)
        print(f"{pcname}:{ip[2]}")

    except Exception as e:
        print(e)

cont=True
while(cont):
    os.system("cls")
    print("===================")
    print("Get pc name or ip")
    print("===================")
    print()
    print("[a] get ip by entering pcname")
    print("[b] get name by entering ip")
    print()

    choice = input("Selection: ").lower()
    if choice=="a":
        findpcbyname()
    elif choice=="b":
        findpcbyip()
    else:
        print("enter from given selection only!")

    print()
    choice2 = input("press x to exit,any other key to continue: ")
    if choice2 == "x":
        cont=False





