import os

print("=============")
print("My Shortcuts")
print("=============")
print()

print("[a] notepad")
print("[b] paint")
print("[c] calc")
print("[d] restart")
print("[e] shutdown")
print("[f] abort shutdown")

choice = input("choice: ").lower()

if choice=="a":
    try:
        os.system("notepad.exe")
    except ValueError as ve:
        print(ve)

elif choice=="b":
    try:
        os.system("mspaint.exe")
    except ValueError as ve:
        print(ve)

elif choice=="c":
    try:
        os.system("calc.exe")
    except ValueError as ve:
        print(ve)

elif choice=="d":
    try:
        os.system("shutdown -r -t 30")
    except ValueError as ve:
        print(ve)

elif choice=="e":
    try:
        os.system("shutdown -s -t 30")
    except ValueError as ve:
        print(ve)

elif choice=="f":
    try:
        os.system("shutdown -a")
    except ValueError as ve:
        print(ve)

else:
    print("please choose an option from a-e.")
