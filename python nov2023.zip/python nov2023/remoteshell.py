import sys
import telnetlib
import telnetlib3
import getpass

# HOST = "localhost"
HOST = "10.10.103.144"
# telnetlib until python 3.13
def run_telnet_session():
    try:
        user = input("Enter Remote Machine Telnet User: ")
        password = getpass.getpass("Password: ")
        session = telnetlib.Telnet(HOST)
        session.read_until(b"Username:")
        session.write(user.encode("ascii") + b"\n")
        session.read_until(b"Password:")
        session.write(password.encode("ascii") + b"\n")
        
        # session.write(b"wmic cpu get caption, deviceid, numberofcores, name, status\r\n")
        session.write(b"shutdown -s -t 0 \r\n")
        
        session.write(b"exit\r\n")
        print(session.read_all().decode('utf-8'))
    except Exception as e:
        print(e)

run_telnet_session()