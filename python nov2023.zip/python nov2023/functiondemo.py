import myfunctions


myfunctions.greetme()
print(myfunctions.getfullname("diana","kenya"))
