# tuples 
# (), readonly

tuple1 = ("January","February","March")
print(tuple1)
print(tuple1[1])

tuple1 = list(tuple1)
tuple1.append("April")

tuple1 = tuple(tuple1)
print(tuple1)

newtuple1 = []

for m in tuple1:
    newtuple1.append(m[0:3])

tuple1 = tuple(newtuple1)
print(tuple1)