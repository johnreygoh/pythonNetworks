# import myfunctions 
from myfunctions import greetme, getfullname

greetme()
print(getfullname("robin","hood"))