# loop 
# for item in collection

try:
    counter = 1
    file1 = open("mynumbers.txt","w")
    
    while(counter <= 100):
        # if counter%2 == 1:
        if counter>50 or counter <40:
            file1.write(f"{str(counter)}\n")
        
        counter += 1
    
    file1.close()

    file1 = open("mynumbers.txt","r")
    content = file1.readlines()
    
    newlist = []
    for i in content:
        # print(i)
        # print(i.replace("\n",""))
        newlist.append(i.replace("\n","")) 

    print(newlist)
    file1.close()

except ValueError as ve:
    print(ve)

